package pb.protocols.keepalive;

public interface IKeepAliveProtocolHandler {

}
