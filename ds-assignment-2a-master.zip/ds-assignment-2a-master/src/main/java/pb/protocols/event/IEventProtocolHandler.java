package pb.protocols.event;


public interface IEventProtocolHandler {
	// actually there is nothing that this protocol specifically
	// needs to signal in the manager, rather manager can listen
	// for events
}
