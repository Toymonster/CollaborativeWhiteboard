package pb.managers.endpoint;

@SuppressWarnings("serial")
public class ProtocolAlreadyRunning extends Exception {

}
